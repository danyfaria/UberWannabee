/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Daniel
 */
public class Servico
{
    private int numServico;
    private int numCliente;
    private String locCliente;
    private String locDestino;
    private Veiculo servVeiculo;
    
    Servico(int nums,int numc, String locc, String locd){
        this.numServico = nums;
        this.numCliente = numc;
        this.locCliente = locc;
        this.locDestino = locd;
        this.servVeiculo = new Veiculo
    }
}