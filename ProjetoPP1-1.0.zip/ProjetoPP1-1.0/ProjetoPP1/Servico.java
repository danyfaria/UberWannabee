
/**
 * Escreva a descrição da classe Servico aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Servico
{
    private int numServico;
    private int numCliente;
    private String locCliente;
    private String locDestino;
    private Veiculo servVeiculo;
    
    Servico(int nums,int numc, String locc, String locd){
        
}
